﻿using System;

namespace QUIZ09092019
{
    class Program
    {
        static void Main(string[] args)
        {
            bangunDatar obj = new bangunDatar();
            obj.luasPersegi();
            obj.luasSegitiga();
            obj.luasLingkaran();
            bangunRuang obj1 = new bangunRuang();
            obj1.volumeBalok();
            obj1.volumeKubus();
        }
    }
}
